<h1 align="center">
  Exercícios do Curso JS do Zero
</h1>

<h6 align="center">🟢 Não é necessário ter conhecimentos de JavaScript, HTML, CSS, Git/GitHub ou Lógica de Programação para fazer o curso. 
  
  É um curso para quem realmente está no zero e quer aprender JavaScript.</h6>

<h6 align="center">O objetivo deste curso é te preparar para a Semana do JavaScript.<h6>

<h6 align="center">As aulas acontecem ao vivo, de segunda à quinta, às 9:15h (horário de Brasília)! Compareça para tirar suas dúvidas ao vivo =D<h6>
</br>

[![Curso JavaScript do Zero](assets/img/banner-javascript-do-zero.jpg)](https://youtube.com/playlist?list=PLpSJMw6H4PFPTcO3pXPi6GBLcX5_8cFJY)

<h2 align="center">Link para o curso</h2>

<p align="center">🔗 https://youtube.com/playlist?list=PLpSJMw6H4PFPTcO3pXPi6GBLcX5_8cFJY</p>

---

<h2 align="center">Como baixar este repositório</h2>

<p align="center">Para baixar este repositório em sua máquina, você pode clicar no botão verde "Code" (ali em cima) e fazer download do .zip ou, caso você tenha noções de Git, você pode forká-lo e/ou cloná-lo.</p> 

---

<h2 align="center">Tem alguma dúvida ou sugestão?</h2>

<p align="center">Envie um email para <a href="mailto:oi@rogermelo.com.br">oi@rogermelo.com.br</a></p>
